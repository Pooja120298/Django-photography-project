from django.conf.urls import url
from photo.views import home,contact,about

urlpatterns = [
    url(r'^about/$', about,name="about"),
    url(r'^contact/$',contact,name="contact")
    

]


