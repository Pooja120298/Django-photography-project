from django.contrib import admin
from photo.models import Photo
# Register your models here.
admin.site.register(Photo)