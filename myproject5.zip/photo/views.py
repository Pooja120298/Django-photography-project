from django.shortcuts import render,redirect
from photo.models import Photo
from photo.forms import PhotoForm

def home(request):
    return render(request,'home.html')

def contact(request):
    photoform=PhotoForm(request.POST or None)
    if photoform.is_valid():
        photoform.save()
        return redirect('home')    
    return render(request,'contact.html',{"forms":photoform})

def about(request):
    return render(request,'about.html')
