from django.db import models

# Create your models here.
class Photo(models.Model):
    title=models.CharField(max_length=255)
    name=models.CharField(max_length=50)
    email=models.CharField(max_length=20)
    mobile=models.CharField(max_length=20)
    description=models.CharField(max_length=255)
    
